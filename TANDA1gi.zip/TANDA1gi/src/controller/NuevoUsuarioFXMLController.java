package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Persona;
import javafx.event.ActionEvent;

public class NuevoUsuarioFXMLController {
	@FXML
	private TextField txtNombre;
	@FXML
	private TextField txtApellido;
	@FXML
	private TextField txtEdad;
	@FXML
	private Button btnGuardar;
	@FXML
	private Button btnCancelar;
	
	private Persona p;

	// Event Listener on Button[#btnGuardar].onAction
	@FXML
	public void anadirPersona(ActionEvent event) {
		p= new Persona(txtNombre.getText(), txtApellido.getText(), txtEdad.getText());
		Stage stage = (Stage) btnGuardar.getScene().getWindow();
		stage.close();
		try {
//			FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/EjercicioG.fxml"));
//			EjercicioGController con= loader.getController();
//	          System.out.println(p);
//	          con.getListaPersona().add(p);
//	          con.getTablaPersona().refresh();
//	          System.out.println(con.getTablaPersona().getItems().get(0));
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	public Persona getP() {
		return p;
	}
}
